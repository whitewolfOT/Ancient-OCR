Kraken training data
====================
To fine-tune Kraken: ketos train -f alto *.gt.txt
See https://kraken.re/main/training.html
